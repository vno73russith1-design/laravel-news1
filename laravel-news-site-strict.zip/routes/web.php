<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\JournalistController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ArticleController::class, 'index'])->name('home');
Route::get('/category/{category?}', [ArticleController::class, 'category'])->name('category');

Route::middleware('guest')->group(function () {
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.store');
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.attempt');
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware('role:journalist')
    ->prefix('journalist')
    ->name('journalist.')
    ->controller(JournalistController::class)
    ->group(function () {
        Route::get('/', 'index')->name('index');
        Route::post('/', 'store')->name('store');
        Route::get('/{text}/edit', 'edit')->name('edit');
        Route::put('/{text}', 'update')->name('update');
    });

Route::middleware('role:admin')
    ->prefix('admin')
    ->name('admin.')
    ->controller(AdminController::class)
    ->group(function () {
        Route::get('/', 'index')->name('index');
        Route::get('/texts/{text}/edit', 'editText')->name('texts.edit');
        Route::put('/texts/{text}', 'updateText')->name('texts.update');
        Route::patch('/texts/{text}/block', 'toggleBlock')->name('texts.block');
        Route::delete('/texts/{text}', 'destroyText')->name('texts.destroy');
        Route::patch('/users/{user}/role', 'updateRole')->name('users.role');
    });
