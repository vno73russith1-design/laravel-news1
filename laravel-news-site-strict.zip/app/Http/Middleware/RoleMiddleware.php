<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();

        if (! $user) {
            return redirect()->guest(route('login'));
        }

        if ($user->hasRole('admin') || $user->hasRole(...$roles)) {
            return $next($request);
        }

        abort(403, 'У вас нет доступа к этому разделу.');
    }
}
