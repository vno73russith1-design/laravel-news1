<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Text;

class ArticleController extends Controller
{
    public function index()
    {
        $articles = Text::with(['category', 'user'])
            ->published()
            ->newestFirst()
            ->paginate(6);

        return view('home', compact('articles'));
    }

    public function category(?Category $category = null)
    {
        $category ??= Category::where('name', 'Технологии')->first();
        abort_if(! $category, 404);

        $articles = $category->texts()
            ->with(['category', 'user'])
            ->published()
            ->newestFirst()
            ->paginate(6);

        return view('category', compact('category', 'articles'));
    }
}
