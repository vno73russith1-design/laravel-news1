<?php

namespace App\Http\Controllers;

use App\Http\Requests\TextRequest;
use App\Models\Category;
use App\Models\Text;
use Illuminate\Support\Facades\Auth;

class JournalistController extends Controller
{
    public function index()
    {
        $categories = Category::orderBy('id')->get();
        $myTexts = Text::with('category')
            ->where('user_id', Auth::id())
            ->newestFirst()
            ->get();

        return view('journalist.index', compact('categories', 'myTexts'));
    }

    public function store(TextRequest $request)
    {
        $data = $request->validated();
        $data['user_id'] = Auth::id();

        Text::create($data);

        return redirect()->route('journalist.index')->with('success', 'Статья опубликована.');
    }

    public function edit(Text $text)
    {
        $this->authorizeOwner($text);
        $categories = Category::orderBy('id')->get();

        return view('journalist.edit', compact('text', 'categories'));
    }

    public function update(TextRequest $request, Text $text)
    {
        $this->authorizeOwner($text);
        $text->update($request->validated());

        return redirect()->route('journalist.index')->with('success', 'Статья обновлена.');
    }

    private function authorizeOwner(Text $text): void
    {
        abort_unless(
            Auth::user()->hasRole('admin') || $text->user_id === Auth::id(),
            403,
            'Это не ваша статья.'
        );
    }
}
