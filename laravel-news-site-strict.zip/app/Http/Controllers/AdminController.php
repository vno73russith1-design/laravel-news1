<?php

namespace App\Http\Controllers;

use App\Http\Requests\TextRequest;
use App\Models\Category;
use App\Models\Role;
use App\Models\Text;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function index()
    {
        $texts = Text::with(['category', 'user'])->newestFirst()->paginate(10);
        $users = User::with('role')->orderBy('id')->get();
        $roles = Role::orderBy('id')->get();

        return view('admin.index', compact('texts', 'users', 'roles'));
    }

    public function editText(Text $text)
    {
        $categories = Category::orderBy('id')->get();

        return view('admin.edit', compact('text', 'categories'));
    }

    public function updateText(TextRequest $request, Text $text)
    {
        $text->update($request->validated());

        return redirect()->route('admin.index')->with('success', 'Статья обновлена.');
    }

    public function destroyText(Text $text)
    {
        $text->delete();

        return back()->with('success', 'Статья удалена.');
    }

    public function toggleBlock(Text $text)
    {
        $text->update(['is_blocked' => ! $text->is_blocked]);

        return back()->with('success', $text->is_blocked ? 'Статья заблокирована.' : 'Статья разблокирована.');
    }

    public function updateRole(Request $request, User $user)
    {
        $data = $request->validate([
            'role_id' => ['required', 'integer', 'exists:roles,id'],
        ], [
            'role_id.required' => 'Выберите роль.',
            'role_id.exists' => 'Такой роли не существует.',
        ]);

        if ($user->id === Auth::id()) {
            return back()->withErrors(['role_id' => 'Нельзя менять роль самому себе.']);
        }

        $user->update(['role_id' => $data['role_id']]);

        return back()->with('success', "Роль пользователя {$user->login} изменена.");
    }
}
