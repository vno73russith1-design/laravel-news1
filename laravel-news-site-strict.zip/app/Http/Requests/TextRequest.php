<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TextRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'heading' => ['required', 'string', 'max:255'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'text' => ['required', 'string'],
        ];
    }

    public function messages(): array
    {
        return [
            'heading.required' => 'Введите заголовок статьи.',
            'heading.max' => 'Заголовок не должен быть длиннее 255 символов.',
            'category_id.required' => 'Выберите категорию.',
            'category_id.exists' => 'Выбранной категории не существует.',
            'text.required' => 'Введите текст статьи.',
        ];
    }
}
