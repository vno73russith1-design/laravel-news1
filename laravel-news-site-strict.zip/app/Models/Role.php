<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Role extends Model
{
    public $timestamps = false;

    protected $fillable = ['name'];

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function getLabelAttribute(): string
    {
        return [
            'user' => 'Пользователь',
            'journalist' => 'Журналист',
            'admin' => 'Администратор',
        ][$this->name] ?? $this->name;
    }
}
