<footer class="site-footer">
    <div class="container">
        <p>&copy; {{ date('Y') }} Научный прогресс. Новостной сайт на Laravel.</p>
    </div>
</footer>
