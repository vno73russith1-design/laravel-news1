@props(['article'])

<article class="article">
    <h2>{{ $article->heading }}</h2>

    <div class="meta">
        <a class="tag" href="{{ route('category', $article->category) }}">{{ $article->category->name }}</a>
        <span>Автор: {{ $article->user->login }}</span>
        <span>{{ $article->created_at->format('d.m.Y H:i') }}</span>
    </div>

    <p>{{ \Illuminate\Support\Str::limit($article->text, 250) }}</p>

    @if (mb_strlen($article->text) > 250)
        <details>
            <summary>Читать полностью</summary>
            <div class="full-text">{!! nl2br(e($article->text)) !!}</div>
        </details>
    @endif
</article>
