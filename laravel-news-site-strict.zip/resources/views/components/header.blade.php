<header class="site-header">
    <div class="container header-inner">
        <a href="{{ route('home') }}" class="logo">Научный прогресс</a>

        <nav class="nav">
            <a href="{{ route('home') }}" @class(['active' => request()->routeIs('home')])>Главная</a>
            <a href="{{ route('category') }}" @class(['active' => request()->routeIs('category')])>Категория</a>

            @if (auth()->check() && auth()->user()->hasRole('journalist', 'admin'))
                <a href="{{ route('journalist.index') }}" @class(['active' => request()->routeIs('journalist.*')])>Журналист</a>
            @endif

            @if (auth()->check() && auth()->user()->hasRole('admin'))
                <a href="{{ route('admin.index') }}" @class(['active' => request()->routeIs('admin.*')])>Админ</a>
            @endif
        </nav>

        <div class="auth-links">
            @auth
                <span class="user-name">{{ auth()->user()->login }} ({{ auth()->user()->role->label }})</span>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="btn btn-small btn-light">Выйти</button>
                </form>
            @else
                <a href="{{ route('login') }}">Вход</a>
                <a href="{{ route('register') }}">Регистрация</a>
            @endauth
        </div>
    </div>
</header>
