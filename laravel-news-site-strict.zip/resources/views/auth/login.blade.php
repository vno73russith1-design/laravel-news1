<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Вход | Научный прогресс</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <x-header />

    <main class="container">
        <div class="auth-box">
            <h1>Вход</h1>

            <form method="POST" action="{{ route('login.attempt') }}" class="form">
                @csrf

                <label for="login">Логин</label>
                <input id="login" type="text" name="login" value="{{ old('login') }}" autofocus>
                @error('login')<div class="error">{{ $message }}</div>@enderror

                <label for="password">Пароль</label>
                <input id="password" type="password" name="password">
                @error('password')<div class="error">{{ $message }}</div>@enderror

                <button type="submit" class="btn">Войти</button>
            </form>

            <p class="muted">Нет аккаунта? <a href="{{ route('register') }}">Зарегистрироваться</a></p>
        </div>
    </main>

    <x-footer />
</body>
</html>
