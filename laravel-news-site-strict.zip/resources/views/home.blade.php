<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Главная | Научный прогресс</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <x-header />

    <main class="container">
        <h1>Все новости</h1>

        @forelse ($articles as $article)
            <x-article-card :article="$article" />
        @empty
            <p class="muted">Пока нет опубликованных статей.</p>
        @endforelse

        {{ $articles->links('vendor.pagination.custom') }}
    </main>

    <x-footer />
</body>
</html>
