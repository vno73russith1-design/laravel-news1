<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Админ | Научный прогресс</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <x-header />

    <main class="container">
        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        @error('role_id')
            <div class="alert alert-error">{{ $message }}</div>
        @enderror

        <h1>Админ-панель</h1>

        <h2>Статьи</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Заголовок</th>
                    <th>Категория</th>
                    <th>Автор</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($texts as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->heading }}</td>
                        <td>{{ $item->category->name }}</td>
                        <td>{{ $item->user->login }}</td>
                        <td>
                            @if ($item->is_blocked)
                                <span class="badge badge-danger">Заблокирована</span>
                            @else
                                <span class="badge badge-ok">Опубликована</span>
                            @endif
                        </td>
                        <td class="actions">
                            <a class="btn btn-small" href="{{ route('admin.texts.edit', $item) }}">Редактировать</a>

                            <form method="POST" action="{{ route('admin.texts.block', $item) }}">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="btn btn-small btn-warning">{{ $item->is_blocked ? 'Разблокировать' : 'Заблокировать' }}</button>
                            </form>

                            <form method="POST" action="{{ route('admin.texts.destroy', $item) }}" onsubmit="return confirm('Удалить статью?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-small btn-danger">Удалить</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="6">Статей пока нет.</td></tr>
                @endforelse
            </tbody>
        </table>

        {{ $texts->links('vendor.pagination.custom') }}

        <h2>Пользователи и роли</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Логин</th>
                    <th>Текущая роль</th>
                    <th>Изменить роль</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($users as $person)
                    <tr>
                        <td>{{ $person->id }}</td>
                        <td>{{ $person->login }}</td>
                        <td>{{ $person->role->label }}</td>
                        <td>
                            @if ($person->id === auth()->id())
                                <span class="muted">это вы</span>
                            @else
                                <form method="POST" action="{{ route('admin.users.role', $person) }}" class="inline-form">
                                    @csrf
                                    @method('PATCH')
                                    <select name="role_id">
                                        @foreach ($roles as $role)
                                            <option value="{{ $role->id }}" @selected($role->id === $person->role_id)>{{ $role->label }}</option>
                                        @endforeach
                                    </select>
                                    <button type="submit" class="btn btn-small">Сохранить</button>
                                </form>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </main>

    <x-footer />
</body>
</html>
