<form method="POST" action="{{ $action }}" class="form">
    @csrf
    @isset($method)
        @method($method)
    @endisset

    <label for="heading">Заголовок</label>
    <input id="heading" type="text" name="heading" value="{{ old('heading', $editing->heading ?? '') }}">
    @error('heading')<div class="error">{{ $message }}</div>@enderror

    <label for="category_id">Категория</label>
    <select id="category_id" name="category_id">
        <option value="">— выберите категорию —</option>
        @foreach ($categories as $category)
            <option value="{{ $category->id }}" @selected(old('category_id', $editing->category_id ?? '') == $category->id)>{{ $category->name }}</option>
        @endforeach
    </select>
    @error('category_id')<div class="error">{{ $message }}</div>@enderror

    <label for="text">Полный текст статьи</label>
    <textarea id="text" name="text" rows="10">{{ old('text', $editing->text ?? '') }}</textarea>
    @error('text')<div class="error">{{ $message }}</div>@enderror

    <button type="submit" class="btn">{{ $button }}</button>
</form>
