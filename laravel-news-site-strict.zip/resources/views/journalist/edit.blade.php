<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Редактирование статьи | Научный прогресс</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <x-header />

    <main class="container">
        <h1>Редактирование статьи</h1>

        <section class="box">
            @include('texts._form', [
                'action' => route('journalist.update', $text),
                'method' => 'PUT',
                'editing' => $text,
                'categories' => $categories,
                'button' => 'Сохранить',
            ])
        </section>

        <p><a href="{{ route('journalist.index') }}">&larr; Назад к списку</a></p>
    </main>

    <x-footer />
</body>
</html>
