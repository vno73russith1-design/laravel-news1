<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Журналист | Научный прогресс</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <x-header />

    <main class="container">
        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <h1>Раздел журналиста</h1>

        <div class="two-col">
            <section class="box">
                <h2>Новая статья</h2>
                @include('texts._form', [
                    'action' => route('journalist.store'),
                    'categories' => $categories,
                    'button' => 'Опубликовать',
                ])
            </section>

            <section class="box">
                <h2>Мои статьи</h2>
                @forelse ($myTexts as $item)
                    <div class="my-article">
                        <div>
                            <strong>{{ $item->heading }}</strong>
                            <span class="muted">· {{ $item->category->name }}</span>
                            @if ($item->is_blocked)
                                <span class="badge badge-danger">Заблокирована</span>
                            @endif
                        </div>
                        <a href="{{ route('journalist.edit', $item) }}" class="btn btn-small">Редактировать</a>
                    </div>
                @empty
                    <p class="muted">Вы ещё не написали ни одной статьи.</p>
                @endforelse
            </section>
        </div>
    </main>

    <x-footer />
</body>
</html>
