<?php

$root = __DIR__;
$skip = ['vendor/', 'node_modules/', 'storage/', '.git/', 'bootstrap/cache/'];

function stripPhp(string $code): string
{
    $out = '';
    foreach (token_get_all($code) as $token) {
        if (is_array($token)) {
            if ($token[0] === T_COMMENT || $token[0] === T_DOC_COMMENT) {
                $out .= "\x01";
            } else {
                $out .= $token[1];
            }
        } else {
            $out .= $token;
        }
    }

    $lines = [];
    foreach (explode("\n", $out) as $line) {
        $clean = rtrim(str_replace("\x01", '', $line));
        if (str_contains($line, "\x01") && trim($clean) === '') {
            continue;
        }
        $lines[] = $clean;
    }

    return preg_replace("/\n{3,}/", "\n\n", implode("\n", $lines));
}

function stripBlade(string $code): string
{
    $code = preg_replace('/^[ \t]*\{\{--.*?--\}\}[ \t]*\R/ms', '', $code);

    return preg_replace('/\{\{--.*?--\}\}/s', '', $code);
}

function stripCss(string $code): string
{
    $code = preg_replace('/^[ \t]*\/\*.*?\*\/[ \t]*\R/ms', '', $code);

    return preg_replace('/\/\*.*?\*\//s', '', $code);
}

$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);

$changed = 0;
$removed = 0;

foreach ($files as $file) {
    $path = $file->getPathname();
    $relative = str_replace('\\', '/', substr($path, strlen($root) + 1));

    foreach ($skip as $prefix) {
        if (str_starts_with($relative, $prefix)) {
            continue 2;
        }
    }

    $name = basename($path);

    if ($relative === 'strip.php') {
        continue;
    }

    if (str_ends_with($name, '.md')) {
        unlink($path);
        $removed++;
        continue;
    }

    if ($relative === 'resources/views/welcome.blade.php') {
        unlink($path);
        $removed++;
        continue;
    }

    $old = file_get_contents($path);

    if (str_ends_with($name, '.blade.php')) {
        $new = stripBlade($old);
    } elseif (str_ends_with($name, '.php') || $name === 'artisan') {
        $new = stripPhp($old);
    } elseif (preg_match('/\.(css|js)$/', $name)) {
        $new = stripCss($old);
    } else {
        continue;
    }

    if ($new !== $old) {
        file_put_contents($path, $new);
        $changed++;
    }
}

echo "Изменено файлов: {$changed}\n";
echo "Удалено файлов (md и welcome): {$removed}\n";

@unlink(__FILE__);
